// Mengambil elemen-elemen HTML
const changeTextButton = document.getElementById('changeTextButton');
const message = document.getElementById('message');
const showAlertButton = document.getElementById('showAlertButton');

// Fungsi untuk mengubah teks paragraf
changeTextButton.addEventListener('click', function() {
    message.textContent = 'Teks ini telah diubah! Terima kasih telah mengklik tombol.';
});

// Fungsi untuk menampilkan alert
showAlertButton.addEventListener('click', function() {
    alert('Selamat! Anda telah menekan tombol alert.');
});